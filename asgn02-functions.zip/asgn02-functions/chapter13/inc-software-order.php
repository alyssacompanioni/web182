<?php

		// PROVIDE THE CODE FOR THE getSubTotal FUNCTION..

		// PROVIDE THE CODE FOR THE getSalesTax FUNCTION..

		// PROVIDE THE CODE FOR THE getShippingHandling FUNCTION..

?>