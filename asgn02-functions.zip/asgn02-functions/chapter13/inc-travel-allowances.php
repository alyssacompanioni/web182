<?php

// add functions here. Refer to bus-travel.php for the correct function names
function getMileageAllowance()
{
  return 0.35;
}

function getBreakfastAllowance()
{
  return 6;
}

function getLunchAllowance()
{
  return 8.50;
}

function getDinnerAllowance(){
  return 17.50;
}

function getHotelAllowance(){
  return 110;
}

?>
